# Spoon-gantiid
Script alternatif untuk mengganti id akun yang sudah terkena limit ganti id 1x

## Installation (Instalasi)



```bash
pkg install python -y
pkg install git -y
git clone https://github.com/diverglovsky/gantiid.git
```

## Usage (Cara pakai)

```bash
cd gantiid
python main.py
```
- Masukkan nomor dan password
- kemudian masukkan id baru  
  
Enjoy ~




## Credit
[Group telegram](https://t.me/joinchat/UPFZEKRg6jTVdpCv) https://t.me/joinchat/UPFZEKRg6jTVdpCv  
